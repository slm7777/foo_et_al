# Example package

This is a simple example package for slm7777's application to UCAR REQ-2024-114 Software Engineer I.
foo_et_al contains a base class foo that can be extended, and a sphere subclass. 

To install the package, type
python -m pip install --index-url https://test.pypi.org/simple/ foo_slm7777

To test, run the sphere.py script

python sphere.py